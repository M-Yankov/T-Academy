﻿namespace EF
{
    public class Point
    {
        public int Left { get; set; }

        public int Top { get; set; }
    }
}
