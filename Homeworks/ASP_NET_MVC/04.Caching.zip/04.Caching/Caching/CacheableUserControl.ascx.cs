﻿namespace Caching
{
    using System;

    public partial class CacheableUserControl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}